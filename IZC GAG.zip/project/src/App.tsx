import React from 'react';
import { PetSelector } from './components/PetSelector';

function App() {
  return (
    <PetSelector />
  );
}

export default App;
